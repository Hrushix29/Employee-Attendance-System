<?php
function isPresentEmp($id){
    include 'dbconnection.php';
    $sql="select count(*) from printdetailsonscan where barcode='$id'";
    $ResultSet=mysqli_query($conn,$sql);
    $rs=mysqli_fetch_row($ResultSet);
    if($rs[0]=='0'){
        return 0;
    }
    else{
        return 1;
    }
}
function isNotCheckIn($id){
    include 'dbconnection.php';
    date_default_timezone_set('Asia/Kolkata');
    $date=date('Y-m-d');
    $sql="select count(*) from check_in_out where barcode=$id and date='$date'";
    $ResultSet=mysqli_query($conn,$sql);
    $rs=mysqli_fetch_row($ResultSet);
    if($rs[0]=='0'){
        return 1;
    }
    else{
        return 0;
    }
}
function getFlag($id){
    include 'dbconnection.php';
    date_default_timezone_set('Asia/Kolkata');
    $date=date('Y-m-d');
    $sql="select flag from check_in_out where barcode=$id and date='$date'";
    $ResultSet=mysqli_query($conn,$sql);
    $rs=mysqli_fetch_row($ResultSet);
    return $rs[0];
}
?>