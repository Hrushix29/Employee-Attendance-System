<?php
$servername = "localhost";
$username = "u487424540_pavan";
$password = "Bb1D2kC4@";
$db="u487424540_pavan";

// Create connection
$conn =mysqli_connect($servername, $username, $password,$db);


function getName($conn,$id){
    $name=mysqli_query($conn,"select name from printdetailsonscan where barcode='$id'");
    $rs=mysqli_fetch_row($name);
    if(is_null($rs)){
        echo "Not Found";
    }
    else{
        echo $rs[0];
    }
}

function getImage($conn,$id){
    $ResultSet=mysqli_query($conn,"select image from printdetailsonscan where barcode='$id';");
    $rs=mysqli_fetch_row($ResultSet);
    if(is_null($rs)){
        return "https://png.pngtree.com/png-vector/20190710/ourmid/pngtree-user-vector-avatar-png-image_1541962.jpg";
    }
    else if($rs[0]==''){
        return "https://png.pngtree.com/png-vector/20190710/ourmid/pngtree-user-vector-avatar-png-image_1541962.jpg";
    }
    else{
        return "image/".$rs[0];
    }
}

function getMaxId($conn){
    $maxid=mysqli_query($conn,"select max(barcode) from printdetailsonscan;");
    $rs=mysqli_fetch_row($maxid);
    if($rs[0]==null){
        return 1000;
    }
    else{
        return $rs[0];
    }
}

function allDetails($conn){
    $sql="select * from printdetailsonscan as p,emp_details as d,emp_sal as s,emp_account as a where p.barcode=d.barcode and p.barcode=s.barcode and p.barcode=a.barcode;";
    $ResultSet=mysqli_query($conn,$sql);
    return $ResultSet;
}


function allAdminUser($conn){
    $sql="select * from adminLogin;";
    $ResultSet=mysqli_query($conn,$sql);
    return $ResultSet;
}
?>