<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
         
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        header {
            background-color: #333;
            color: #fff;
            display: flex;
            align-items: center;
            padding: 10px 20px;
            width: 100%;
            animation: slideDownHeader 1s ease-out;
        }

        .pavan-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-right: 20px;
        }
        .pavan-logo img{
            border-radius: 50%;
        }

        .pavan-heading h1 {
            margin: 0;
        }

        .pavan-heading h2 {
            margin: 5px 0 0;
            font-size: 1.2em;
        }
        .main-sec{
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image:url("image/gear.jpeg");
            background-repeat:no-repeat;
            background-size:cover;
          
        }

        .container {
            width: 100%;
            max-width: 400px;
        
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;

            animation: fadeIn 1s ease-in;
        }

        .button-container {
            margin-bottom: 20px;
        }

        .login-btn {
            padding: 10px 20px;
            margin: 10px;
            font-size: 16px;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .login-btn:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .login-container {
            display: none;
            animation: slideDown 0.5s ease-out;
        }

        .login-form {
            margin-top: 20px;
        }

        .input-field {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .submit-btn {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .submit-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideDownHeader {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 480px) {
            .container {
                width: 95%;
                margin: 20px;
            }
            .pavan-heading h1 {
            margin: 0;
            font-size: 18px;
            
        }

        .pavan-heading h2 {
            margin: 5px 0 0;
            font-size: 1em;
        }
        }
    </style>
</head>
<body>
    <header>
        <div class="pavan-logo"><img src="image/PE.png" width="100%"></div>
        <div class="pavan-heading">
            <h1>Pavan Engineering Company</h1>
            <h2>Employee Attendance System</h2>
        </div>
    </header>
    <section class="main-sec">
    <div class="container" id="container">
        <div class="button-container">
            <button class="login-btn" onclick="showEmployeeLogin()">Employee Login</button>
            <button class="login-btn" onclick="showAdminLogin()">Admin Login</button>
        </div>
        <div class="login-container" id="login-container">
            <!-- Login forms will appear here -->
        </div>
    </div>
</section>
    <script>
        function showEmployeeLogin() {
            const loginContainer = document.getElementById('login-container');
            loginContainer.innerHTML = `
                <div class="login-form">
                    <form method="post">
                    <h2>Employee Login</h2>
                    <input type="text" class="input-field" placeholder="Username" name="username" required>
                    <input type="password" class="input-field" placeholder="Password" name="password"  required>
                    <button class="submit-btn" name="emp">Login</button>
                    </form>
                </div>
            `;
            loginContainer.style.display = 'block';
        }

        function showAdminLogin() {
            const loginContainer = document.getElementById('login-container');
            loginContainer.innerHTML = `
                <div class="login-form">
                    <form method="post">
                    <h2>Admin Login</h2>
                    <input type="text" class="input-field" placeholder="Username" name="username" required>
                    <input type="password" class="input-field" placeholder="Password"  name="password" required>
                    <button class="submit-btn" name="admin">Login</button>
                    </form>
                </div>
            `;
            loginContainer.style.display = 'block';
        }
    </script>
    <?php
        if(isset($_POST['admin'])){
            // code for admin login 
            include 'db.php';
            $username=$_POST['username'];
            $password=$_POST['password'];
            $ResultSet=allAdminUser($conn);
            $flag=0;
            while($rs=mysqli_fetch_row($ResultSet)){
                if($rs[0]==$username && password_verify($password,$rs[1])){
                    $_SESSION['pavanusername']=$rs[0];
                    $flag=1;
                    echo "<script>";
                    echo "window.location.href='home.php';";
                    echo "</script>";
                }
            }
            if($flag==0){
                echo "<script>alert('Username And Password Wrong.');</script>";
            }
        }
        if(isset($_POST['emp'])){
            // write code for empolyee verification and redirect
            echo "<script>alert('That Functionality Work Within 5 days.');</script>";
        }
    ?>
</body>
</html>
