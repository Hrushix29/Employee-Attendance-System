<?php
$servername = "localhost";
$username = "u487424540_pavan";
$password = "Bb1D2kC4@";
$db="u487424540_pavan";

// Create connection
$conn =mysqli_connect($servername, $username, $password,$db);
?>