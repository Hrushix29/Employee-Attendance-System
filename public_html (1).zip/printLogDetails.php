<?php
    function getTopFive(){
        include 'dbconnection.php';
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d');
        $sql="select p.barcode,name,date,check_in,check_out,time from printdetailsonscan as p,check_in_out as c where p.barcode=c.barcode and date='$date' order by time desc limit 0,5;";
        $ResultSet=mysqli_query($conn,$sql);
        return $ResultSet;
    }
    function getLogDetails($id,$from,$to){
        include 'dbconnection.php';
        $sql="select * from printdetailsonscan as p,check_in_out as c where p.barcode=c.barcode and c.barcode=$id and date>='$from' and date<='$to' order by date desc;";
        $ResultSet=mysqli_query($conn,$sql);
        return $ResultSet;
    }
?>