<?php
session_start();
$pavan = $_SESSION['pavanusername'];
if (!isset($pavan)) {
    header("Location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee</title>
    <!-- <link rel="stylesheet" href="emp.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">


</head>
<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Times New Roman', Times, serif;
}



.pavan-logo {
    width: 80px;
    height: 80px;
   
    border-radius: 50%;
    margin-left: 20px;
}

.pavan-logo img {
    border-radius: 50%;
}

.pavan-heading {
    margin-left: 20px;
}



main {
    height: 100vh;
    width: 100vw;
    display: flex;
    justify-content: center;
    /* align-items: center;
    text-align: center; */

}


#idcard {
    border-radius: 20px;
    align-items: center;
    background-color: rgb(240, 235, 235);
    box-shadow: rgba(255, 255, 255, 0.1) 0px 1px 1px 0px inset, rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px;
    background-image: linear-gradient(white, white);

}

#id-header {
    height: 75px;
    width: 100%;
    display: flex;
    align-items: center;
    margin-top: 15px;
    text-align: center;
}

.logo {
    height: 70px;
    width: 70px;
    border-radius: 50%;
    margin-left: 20px;
    background-image: url("image/PE.png");
    background-repeat: no-repeat;
    background-size: cover;

}

#id-header h6 {
    font-size: 20px;
    font-weight: 600;
    margin-left: 40px;
}

/*                
 ignore please :) | 
                    
#id-header h6:hover{
    cursor: pointer;
} */
.emp-img {
    height: 180px;
    width: 180px;
    border-radius: 50%;
    margin-bottom: 30px;
    background-repeat: no-repeat;
    background-size: cover;
    margin-top: 50px;
}

.emp-img img {
    height: 180px;
    width: 180px;
    border-radius: 50%;
}

#idcard {
    height: 600px;
    width: 350px;
    display: flex;
    flex-direction: column;
  
    /* text-align: center;
    align-items: center; */
}

.emp-info {
    height: 90px;
    width: 100%;
    padding: 15px;
    display: flex;
}

.barcode-section {
    height: 55px;
    width: 90%;
    margin-top: 40px;
    background-color: rgb(240, 235, 235);
    text-align: center;
  
}

.barcode {
    height: 70px;
    width: 100%;
}
.back_button{
            margin:20px;
           
        }
        .back_button button{
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .back_button button:hover {
            background-color: #0056b3;
        }
        .s-input{
        max-width: 500px;
        margin: 30px;
        font-weight: bold;
       
    }
    .s-input input{
        width: 250px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
            margin-top: 10PX;
            
    }
    .s-input label{
        font-size: 19px;
    }
    .s-input button{
        background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-top:7px;
    }
    .s-input button:hover {
            background-color: #0056b3;
        }
    .s-input input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        }
         @media (max-width: 400px) {
             
             .back_button{
                 display:none;
             }
         }
</style>

<body>
    <header>
       <?php
       include "header.php";
       ?>
    </header>
    <div class="back_button"><button onclick="homeRedirect()">Back</button></div>
    <section class="s-input">
        <label>Enter Employee Id Number:</label><br>
        <form action="emp.php" method="post">
        <input type="number" placeholder="Id Number" name="id" required>
        <button type="submit" name="search">Submit</button>
        </form>
    <?php
        if (isset($_POST['search'])) {
            include 'removeBackend.php';
            include 'dbconnection.php';
            include 'db.php';
            $id = $_POST['id'];
            $image=getImage($conn,$id);
            $rs=checkEmpPresent($conn,$id);
            if ($id == 0) {
                echo "<script>alert('Please Enter Employee Id.');</script>";
            }
            else if($rs[0]==0){
                echo "<script>alert('Employee Not Found.');</script>";
            }
            else{
                    
            }
        }
        ?>
        </section>
    <main>

        <div id="idcard">
            <div id="id-header">
                <div class="logo"></div>
                <h6>Pavan Engineering <br>Company</h6>
            </div>

            <div class="emp-img">
                <img src="<?php echo $image ;?>" alt="">
            </div>
            <div class="emp-info">
                
                <div class="info">
                    <h3>Name: <?php if(isset($_POST['search'])){ if($rs[0]>=1){echo " ".getName($conn,$id);} }?></h3><br>
                    <h3 style="padding-left:0px; margin-left:0px;">Id:<?php if(isset($_POST['search'])){ if($rs[0]>=1){ echo "  ".$id;} }?></h3>
                </div>

            </div>
            <div class="barcode-section">
                <img src="image/barcode .png" alt="Barcode1" class="barcode" />
                
            </div>
            <form action="fpdf186/idcard.php" method="post">
            <button type="submit" id="btn" class="btn btn-primary" value="<?php if(isset($_POST['search'])){ if($rs[0]>=1){ echo $id; } else echo 0; }?>" name="download" style="margin-top:20px;" onclick=" return myfun();">Dowload Id Card</button>
    </form>
        <script>
            function myfun(){
                var i=document.getElementById('btn').value;
                if(i==0){
                    window.alert("Please Fill The Employee Id Then You Can Dowload.");
                    return false;
                }
                return true;
            }
            </script>
        </div>


        </div>
    </main>
    <script src="JavaScript/script.js">
       
        </script>
</body>
</html>