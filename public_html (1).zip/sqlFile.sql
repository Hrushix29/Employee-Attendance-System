-- drop database
drop database if exists pavan;
-- create database
create database pavan;
-- use pavan database
use pavan;
-- create tabele 
create table printdetailsonscan(barcode int primary key,name text,image text);
create table emp_details(id int primary key auto_increment,phone text,address text,adhar text,pan text,barcode int,foreign key(barcode) references printdetailsonscan(barcode)on delete cascade on update cascade);
create table emp_sal(id int primary key auto_increment,sal float,join_date date,barcode int,foreign key(barcode) references printdetailsonscan(barcode)on delete cascade on update cascade);
 create table emp_account(id int primary key auto_increment,account text,ifsc text,barcode int,foreign key(barcode) references printdetailsonscan(barcode)on delete cascade on update cascade);
create table adminLogin(username text,password varchar(255));
create table check_in_out(id int primary key auto_increment,date date,check_in text,check_out text,flag int,time text,barcode int,foreign key(barcode) references printdetailsonscan(barcode) on delete cascade on update cascade);
insert into adminlogin values('pavan9130','$2y$10$lCY91kfPPx8k1ELCZq1OVuV9UkbP2oyZzdBc/HFP9J7u15uFVl//m');