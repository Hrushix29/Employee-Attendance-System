<?php
function dellInfo($id)
{
    include 'dbconnection.php';
    $sql = "select p.barcode,name,phone from printdetailsonscan as p,emp_details as e where p.barcode=e.barcode and p.barcode=$id;";
    $ResultSet = mysqli_query($conn, $sql);
    return $ResultSet;
}

function checkEmpPresent($conn,$id){
    $sql="select count(*) from printdetailsonscan where barcode=$id;";
    $ResultSet=mysqli_query($conn,$sql);
    $rs=mysqli_fetch_row($ResultSet);
    return $rs;
}
function empDel($id){
    include 'dbconnection.php';
    $sql="delete from printdetailsonscan where barcode=$id;";
    $sql2="select image from printdetailsonscan where barcode=$id";
    $Result=mysqli_query($conn,$sql2);
    $rs=mysqli_fetch_row($Result);
    $del='image/'.$rs[0];
    unlink($del);
    $Result=mysqli_query($conn,$sql);
    $Result=mysqli_query($conn,$sql2);
    $rs=mysqli_fetch_row($Result);
    $del='image/'.$rs[0];
    unlink($del);
}
?>
