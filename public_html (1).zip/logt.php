<?php
    session_start();
    if (!isset($_SESSION['pavanusername'])) {
    header("Location:index.php");
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .table-container {
            padding:15px;
            width: 100%;
            overflow-x: hidden; /* Allows horizontal scrolling on smaller devices */
        }

        table {
            width: 98%;
            border-collapse: collapse;
            margin: 20px 0;
            min-width: 400px; /* Ensures minimum width for the table */
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
        }

        @media screen and (max-width: 600px) {
            table, tbody, th, td, tr {
                display: block;
            }

            thead tr {
                display: none; /* Hide header on smaller screens */
            }

            tr {
                margin-bottom: 15px;
            }

            td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }

            td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: 50%;
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: bold;
            }
        }
         .form-container {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      max-width: 800px;
      margin: 0 auto;
      padding:50px;
      gap: 10px;
    }

    .form-container input, .form-container button {
      padding: 10px;
      font-size: 16px;
      width: 100%;
    }

    .form-container input[type="date"], .form-container input[type="text"] {
      flex: 1;
      min-width: 150px;
    }

    .form-container button {
      background-color: #007BFF;
      color: white;
      border: none;
      cursor: pointer;
      min-width: 100px;
    }

    .form-container button:hover {
      background-color: #0056b3;
    }

    @media (max-width: 600px) {
      .form-container {
        flex-direction: column;
        gap: 15px;
      }

      .form-container input[type="date"], .form-container input[type="text"] {
        width: 100%;
      }
    }
    </style>
</head>
<body>
    <header>
        <?php
        include "header.php";
        ?>
    </header>
    <button style="background-color: #007BFF;
      color: white;
      border: none;
      margin:20px;
      cursor: pointer;
      min-width: 100px;
      height:20px;" onclick="window.location.href='home.php'">Back</button>
      <form method="post">
        <div class="form-container">
            <input type="text" placeholder="Search By Id" name="id" required>
            <input type="date" placeholder="Start Date" name="from" required>TO
            <input type="date" placeholder="End Date" name="to" required>
            <button type="search" name="search">Search</button>
        </div>
    </form>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Check-in Time</th>
                    <th>Check-out Time</th>
                </tr>
            </thead>
            <tbody>
                <?php
                        include 'printLogDetails.php';
                        ?>
                        <?php
                        if (isset($_POST['search'])) {
                            $empid = $_POST['id'];
                            $from = $_POST['from'];
                            $to = $_POST['to'];
                            include 'dbconnection.php';
                             $sql="select count(*) from printdetailsonscan where barcode=$empid;";
                             $ResultSet=mysqli_query($conn,$sql);
                             $rs=mysqli_fetch_row($ResultSet);
                            if ($rs[0] == 0) {
                                echo "<script>alert('Employee Not Found.');</script>";
                            } else {
                                $ResultSet = getLogDetails($empid, $from, $to);
                                while ($rs = mysqli_fetch_row($ResultSet)) { ?>
                                    <tr>
                                        <td><?php echo $rs[0]; ?></td>
                                        <td><?php echo $rs[1]; ?></td>
                                        <td><?php echo $rs[4]; ?></td>
                                        <td><?php echo $rs[5]; ?></td>
                                        <td><?php echo $rs[6]; ?></td>
                                    </tr>

                        <?php }
                            }
                        }
                        ?>

                <!-- More rows as needed -->
            </tbody>
        </table>
    </div>
</body>
</html>
